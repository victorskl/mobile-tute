using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(VictorTodoService.Startup))]

namespace VictorTodoService
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureMobileApp(app);
        }
    }
}